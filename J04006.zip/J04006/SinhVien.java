package J04006;
import  java.util.*;
import java.text.*;
public class SinhVien {
    private String maSV, ten, lop;
    private Date ngaysinh;
    private float gpa;
    public SinhVien(String ten, String lop, String ngaysinh, float gpa) throws ParseException {
        this.maSV = "B20DCCN001";
        this.ten = ten;
        this.lop = lop;
        this.ngaysinh = new SimpleDateFormat("dd/MM/yyyy").parse(ngaysinh);
        this.gpa = gpa;
    }

    public String toString() {
        return maSV + " " + ten + " " + lop + " " + new SimpleDateFormat("dd/MM/yyyy").format(ngaysinh) + " " + String.format("%.2f", gpa);
    }
}
