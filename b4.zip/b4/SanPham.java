package b4;

public class SanPham {
    private static int dem = 0;
    private String masp;
    private String tensp;
    private String gia;
    private int bh;
    public SanPham(String masp, String tensp, double gia, int bh) {
        this.masp = masp;
        this.tensp = tensp;
        this.gia = gia;
        this.bh = bh;
    }
    public String getMasp() {
        return masp;
    }

    public String getTensp() {
        return tensp;
    }

    public String getGia() {
        return gia;
    }

    public int getBh() {
        return bh;
    }
}
