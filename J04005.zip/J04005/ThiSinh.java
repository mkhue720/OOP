package J04005;

public class ThiSinh {
    private String hoTen;
    private String ngaySinh;
    private float diemMon1;
    private float diemMon2;
    private float diemMon3;
    private float tongDiem;

    public void nhapThongTin(String hoTen, String ngaySinh, float diemMon1, float diemMon2, float diemMon3) {
        this.hoTen = hoTen;
        this.ngaySinh = ngaySinh;
        this.diemMon1 = diemMon1;
        this.diemMon2 = diemMon2;
        this.diemMon3 = diemMon3;
        this.tongDiem = diemMon1 + diemMon2 + diemMon3;
    }

    public void inThongTin() {
        System.out.printf("%s %s %.1f\n", hoTen, ngaySinh, tongDiem);
    }
}
