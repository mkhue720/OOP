import java.util.*;
import J04005.ThiSinh;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String hoTen = sc.nextLine();
        String ngaySinh = sc.nextLine();
        float diemMon1 = sc.nextFloat();
        float diemMon2 = sc.nextFloat();
        float diemMon3 = sc.nextFloat();

        ThiSinh thiSinh = new ThiSinh();
        thiSinh.nhapThongTin(hoTen, ngaySinh, diemMon1, diemMon2, diemMon3);
        thiSinh.inThongTin();
    }
}
