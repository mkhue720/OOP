package J04015;

public class GiaoVien {
    private String chucvu;
    private String hoten;
    private int bacluong;
    private long luongcoban;
    private long phucap;
    private long thuNhap;

    public GiaoVien(String chucvu, String hoten, long luongcoban) {
        this.chucvu = chucvu;
        this.hoten = hoten;
        this.luongcoban = luongcoban;
        this.bacluong = Integer.parseInt(chucvu.substring(2));
        setPhucap();
        tinhLuong();
    }

    private void setPhucap() {
        switch (chucvu.substring(0, 2)) {
            case "HT":
                this.phucap = 2000000;
                break;
            case "HP":
                this.phucap = 900000;
                break;
            case "GV":
                this.phucap = 500000;
                break;
            default:
                this.phucap = 0;
                break;
        }
    }

    private void tinhLuong() {
        this.thuNhap = luongcoban * bacluong + phucap;
    }

    public String toString() {
        return chucvu + " " + hoten + " " + bacluong + " " + phucap + " " + thuNhap;
    }
}
