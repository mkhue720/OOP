package J04015;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String chucvu = sc.nextLine();
        String hoten = sc.nextLine();
        long luongcoban = sc.nextLong();
        GiaoVien giaoVien = new GiaoVien(chucvu, hoten, luongcoban);
        System.out.println(giaoVien);
    }
}
